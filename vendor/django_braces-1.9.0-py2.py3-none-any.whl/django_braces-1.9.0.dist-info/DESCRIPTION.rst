Mixins to add easy functionality to Django class-based views, forms, and models.


