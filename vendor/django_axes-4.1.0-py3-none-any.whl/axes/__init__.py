__version__ = '4.1.0'

default_app_config = 'axes.apps.AppConfig'


def get_version():
    return __version__
