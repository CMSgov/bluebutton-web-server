"""Module allowing for ``python -m flake8 ...``."""
from flake8.main import cli

cli.main()
