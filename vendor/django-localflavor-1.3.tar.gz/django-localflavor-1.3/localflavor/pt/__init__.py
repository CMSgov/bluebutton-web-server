# -*- coding: utf-8 -*-


"""
django_localflavot_pt
~~~~~~~~~~~~~~~~~~~~~
Country-specific Django helpers for Portugal.
"""
