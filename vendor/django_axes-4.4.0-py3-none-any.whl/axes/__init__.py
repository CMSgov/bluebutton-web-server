from __future__ import unicode_literals

__version__ = '4.4.0'

default_app_config = 'axes.apps.AppConfig'


def get_version():
    return __version__
