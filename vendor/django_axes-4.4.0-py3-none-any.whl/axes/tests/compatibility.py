from __future__ import unicode_literals

try:
    from unittest.mock import patch  # pylint: disable=unused-import
except ImportError:
    from mock import patch  # pylint: disable=unused-import
