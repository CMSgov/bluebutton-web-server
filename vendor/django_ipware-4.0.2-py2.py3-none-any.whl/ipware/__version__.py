__title__ = 'django-ipware'
__author__ = 'Val Neekman'
__author_email__ = 'info@neekware.com'
__description__ = "A Django application to retrieve user's IP address"
__url__ = 'https://github.com/un33k/django-ipware'
__license__ = 'MIT'
__copyright__ = 'Copyright 2020 Val Neekman @ Neekware Inc.'
__version__ = '4.0.2'
