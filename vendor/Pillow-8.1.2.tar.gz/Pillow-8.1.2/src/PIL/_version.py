# Master version for Pillow
__version__ = "8.1.2"
