from newrelic.admin import main

main()
