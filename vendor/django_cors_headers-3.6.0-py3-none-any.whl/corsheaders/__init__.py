from corsheaders.checks import check_settings  # noqa: F401
