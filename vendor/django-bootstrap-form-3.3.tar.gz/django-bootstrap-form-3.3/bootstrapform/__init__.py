from .meta import VERSION


__version__ = str(VERSION)

