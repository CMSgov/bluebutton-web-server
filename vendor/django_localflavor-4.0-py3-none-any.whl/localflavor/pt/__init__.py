"""
django_localflavot_pt
~~~~~~~~~~~~~~~~~~~~~
Country-specific Django helpers for Portugal.
"""
