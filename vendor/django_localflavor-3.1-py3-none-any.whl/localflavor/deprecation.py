class RemovedInLocalflavor30Warning(PendingDeprecationWarning):
    pass
