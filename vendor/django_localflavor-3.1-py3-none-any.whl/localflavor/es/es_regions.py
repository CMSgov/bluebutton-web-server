from django.utils.translation import gettext_lazy as _

#: An alphabetical list of regions
REGION_CHOICES = (
    ('AN', _('Andalusia')),
    ('AR', _('Aragon')),
    ('O', _('Principality of Asturias')),
    ('IB', _('Balearic Islands')),
    ('PV', _('Basque Country')),
    ('CN', _('Canary Islands')),
    ('S', _('Cantabria')),
    ('CM', _('Castile-La Mancha')),
    ('CL', _('Castile and Leon')),
    ('CT', _('Catalonia')),
    ('EX', _('Extremadura')),
    ('GA', _('Galicia')),
    ('LO', _('La Rioja')),
    ('M', _('Madrid')),
    ('MU', _('Region of Murcia')),
    ('NA', _('Foral Community of Navarre')),
    ('VC', _('Valencian Community')),
    ('CE', _('Autonomous city of Ceuta')),
    ('ML', _('Autonomous city of Mellila')),
)
